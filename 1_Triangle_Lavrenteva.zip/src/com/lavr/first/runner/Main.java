package com.lavr.first.runner;

import com.lavr.first.action.TriangleAction;
import com.lavr.first.creator.CreateTriangle;
import com.lavr.first.entity.Triangle;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

/**
 * Created by 123 on 27.09.2016.
 */
public class Main {
    static final Logger LOG = LogManager.getLogger();

    public static void main(String[] args) {
        CreateTriangle ct=new CreateTriangle();
        List<Triangle> triangleList=ct.createListOfTriangles();
        TriangleAction action=new TriangleAction();
        for (Triangle triangle:triangleList) {
            LOG.info("Perimeter of triangle "+triangle+action.countPerimeter(triangle));
            LOG.info("Square of triangle "+triangle+action.countSquare(triangle));
        }
    }
}
