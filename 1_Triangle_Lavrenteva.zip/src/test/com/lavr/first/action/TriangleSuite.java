package test.com.lavr.first.action;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@Suite.SuiteClasses({CheckExistanceTest.class,TriangleActionTest.class})
@RunWith(Suite.class)
public class TriangleSuite {
}
